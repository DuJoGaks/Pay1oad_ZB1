from django.apps import AppConfig


class ApptConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AppT'
